
For dev mode, run:
> ./gradlew -t client:watch
> cd client
> yarn run start



Note that "gradle :client:run" doesn't close correctly (node remains running).