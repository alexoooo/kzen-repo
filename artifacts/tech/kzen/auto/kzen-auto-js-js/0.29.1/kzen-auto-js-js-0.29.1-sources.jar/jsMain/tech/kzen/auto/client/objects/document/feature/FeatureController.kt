package tech.kzen.auto.client.objects.document.feature

import emotion.react.css
import js.objects.unsafeJso
import mui.material.Button
import mui.material.ButtonVariant
import mui.material.Size
import mui.system.sx
import react.ChildrenBuilder
import react.Props
import react.RefObject
import react.State
import react.dom.html.ReactHTML.br
import react.dom.html.ReactHTML.div
import react.dom.html.ReactHTML.hr
import react.dom.html.ReactHTML.img
import react.dom.html.ReactHTML.span
import tech.kzen.auto.client.api.ReactWrapper
import tech.kzen.auto.client.objects.document.DocumentController
import tech.kzen.auto.client.service.global.NavigationGlobal
import tech.kzen.auto.client.service.rest.ClientRestApi
import tech.kzen.auto.client.util.async
import tech.kzen.auto.client.wrap.RPureComponent
import tech.kzen.auto.client.wrap.createRef
import tech.kzen.auto.client.wrap.cropper.CropperDetail
import tech.kzen.auto.client.wrap.cropper.CropperWrapper
import tech.kzen.auto.client.wrap.iconify.icon
import tech.kzen.auto.client.wrap.react
import tech.kzen.auto.client.wrap.setState
import tech.kzen.auto.common.objects.document.feature.FeatureDocument
import tech.kzen.lib.common.exec.BinaryExecutionValue
import tech.kzen.lib.common.exec.ExecutionSuccess
import tech.kzen.lib.common.exec.RequestParams
import tech.kzen.lib.common.model.definition.GraphDefinitionAttempt
import tech.kzen.lib.common.model.document.DocumentPath
import tech.kzen.lib.common.model.location.ObjectLocation
import tech.kzen.lib.common.model.location.ResourceLocation
import tech.kzen.lib.common.model.structure.GraphStructure
import tech.kzen.lib.common.model.structure.notation.cqrs.*
import tech.kzen.lib.common.model.structure.resource.ResourceName
import tech.kzen.lib.common.model.structure.resource.ResourceNesting
import tech.kzen.lib.common.model.structure.resource.ResourcePath
import tech.kzen.lib.common.reflect.Reflect
import tech.kzen.lib.common.reflect.Service
import tech.kzen.lib.common.service.store.LocalGraphStore
import tech.kzen.lib.common.service.store.MirroredGraphStore
import tech.kzen.lib.common.util.ImmutableByteArray
import tech.kzen.lib.platform.DateTimeUtils
import tech.kzen.lib.platform.IoUtils
import web.cssom.*


//---------------------------------------------------------------------------------------------------------------------
external interface FeatureControllerProps: Props {
    var mirroredGraphStore: MirroredGraphStore
    var navigationGlobal: NavigationGlobal
    var restClient: ClientRestApi
}


external interface FeatureControllerState: State {
    var documentPath: DocumentPath?
    var graphStructure: GraphStructure?

    var detail: CropperDetail?
    var screenshotDataUrl: String?
    var capturedDataUrl: String?
    var requestingScreenshot: Boolean?
}


//---------------------------------------------------------------------------------------------------------------------
@Suppress("unused")
class FeatureController(
    props: FeatureControllerProps
):
    RPureComponent<FeatureControllerProps, FeatureControllerState>(props),
    NavigationGlobal.Observer,
    LocalGraphStore.Observer
{
    //-----------------------------------------------------------------------------------------------------------------
    @Reflect
    class Wrapper(
        private val archetype: ObjectLocation,
        @Service private val mirroredGraphStore: MirroredGraphStore,
        @Service private val navigationGlobal: NavigationGlobal,
        @Service private val restClient: ClientRestApi
    ):
        DocumentController
    {
        override fun archetypeLocation(): ObjectLocation {
            return archetype
        }


        override fun header(): ReactWrapper<Props> {
            return object: ReactWrapper<Props> {
//                override fun child(builder: ChildrenBuilder, block: Props.() -> Unit) {}
                override fun ChildrenBuilder.child(block: Props.() -> Unit) {}
            }
        }


        override fun body(): ReactWrapper<Props> {
            return object: ReactWrapper<Props> {
                override fun ChildrenBuilder.child(block: Props.() -> Unit) {
                    FeatureController::class.react {
                        mirroredGraphStore = this@Wrapper.mirroredGraphStore
                        navigationGlobal = this@Wrapper.navigationGlobal
                        restClient = this@Wrapper.restClient
                        block()
                    }
                }
            }
        }
    }


    //-----------------------------------------------------------------------------------------------------------------
    private var cropperWrapper: RefObject<CropperWrapper> = createRef()


    //-----------------------------------------------------------------------------------------------------------------
    override fun FeatureControllerState.init(props: FeatureControllerProps) {
        documentPath = null
        graphStructure = null

        detail = null
        screenshotDataUrl = null
        capturedDataUrl = null
        requestingScreenshot = false
    }


    override fun componentDidMount() {
        async {
            props.mirroredGraphStore.observe(this)
            props.navigationGlobal.observe(this)
        }

        if (state.screenshotDataUrl == null) {
            setState {
                requestingScreenshot = true
            }
        }
    }


    override fun componentWillUnmount() {
        props.mirroredGraphStore.unobserve(this)
        props.navigationGlobal.unobserve(this)
    }


    override fun componentDidUpdate(
        prevProps: FeatureControllerProps,
        prevState: FeatureControllerState,
        snapshot: Any
    ) {
        if (state.screenshotDataUrl == null && state.requestingScreenshot != true) {
            setState {
                requestingScreenshot = true
            }
        }

        if (state.requestingScreenshot == true && prevState.requestingScreenshot != true) {
            doRequestScreenshot()
        }
    }


    //-----------------------------------------------------------------------------------------------------------------
    override fun handleNavigation(
        documentPath: DocumentPath?,
        parameters: RequestParams
    ) {
        setState {
            this.documentPath = documentPath
        }
    }


    override suspend fun onCommandSuccess(
        event: NotationEvent, graphDefinition: GraphDefinitionAttempt, attachment: LocalGraphStore.Attachment
    ) {
        if ((event is DeletedDocumentEvent || event is RenamedDocumentRefactorEvent) &&
                event.documentPath == state.documentPath) {
            return
        }

        setState {
            this.graphStructure = graphDefinition.graphStructure
        }
    }


    override suspend fun onCommandFailure(
        command: NotationCommand, cause: Throwable, attachment: LocalGraphStore.Attachment
    ) {}


    override suspend fun onStoreRefresh(graphDefinitionAttempt: GraphDefinitionAttempt) {
        setState {
            this.graphStructure = graphDefinitionAttempt.graphStructure
        }
    }


    //-----------------------------------------------------------------------------------------------------------------
    private fun doRequestScreenshot() {
        async {
//            console.log("doRequestScreenshot", screenshotTakerLocation.toString())
            val result = props.restClient.performDetached(
                FeatureDocument.screenshotTakerLocation)

            if (result is ExecutionSuccess) {
                val screenshotPng = result.value as BinaryExecutionValue
                val base64 = IoUtils.base64Encode(screenshotPng.value)
                val screenshotPngUrl = "data:png/png;base64,$base64"

                setState {
                    screenshotDataUrl = screenshotPngUrl
                    requestingScreenshot = false
                }
            }
        }
    }


    //-----------------------------------------------------------------------------------------------------------------
    private fun onRefresh() {
        setState {
            capturedDataUrl = null
            screenshotDataUrl = null
        }
    }


    //-----------------------------------------------------------------------------------------------------------------
    private fun onRemove(resourcePath: ResourcePath) {
        async {
            props.mirroredGraphStore.apply(RemoveResourceCommand(
                ResourceLocation(
                    state.documentPath!!,
                    resourcePath)
            ))
        }
    }


    //-----------------------------------------------------------------------------------------------------------------
    private fun onCrop(detail: CropperDetail) {
        setState {
            this.detail = detail
        }
    }


    private fun onSave() {
        state.detail
            ?: return

        cropperWrapper.current!!.getCroppedCanvas().then { canvas ->
            val dataUrl = canvas.toDataURL("image/png")
            val cropPng = IoUtils.base64Decode(dataUrl.substringAfter(","))

            setState {
                capturedDataUrl = dataUrl
                requestingScreenshot = true
            }

            async {
                props.mirroredGraphStore.apply(AddResourceCommand(
                    ResourceLocation(
                        state.documentPath!!,
                        ResourcePath(
                            ResourceName(DateTimeUtils.filenameTimestamp() + ".png"),
                            ResourceNesting.empty)),
                    ImmutableByteArray.wrap(cropPng)
                ))

                onRefresh()
            }
        }
    }


    private fun onCapture() {
        setState {
            capturedDataUrl = null
        }
    }


    //-----------------------------------------------------------------------------------------------------------------
    override fun ChildrenBuilder.render() {
        val documentPath = state.documentPath
            ?: return

        val graphStructure = state.graphStructure
            ?: return

        val documentNotation = graphStructure.graphNotation.documents[documentPath]!!
        val resources = documentNotation.resources!!

        div {
            css {
                padding = 1.em
            }

            for (resource in resources.digests) {
                val resourceLocation = ResourceLocation(documentPath, resource.key)
                val resourceUri = props.restClient.resourceUri(resourceLocation)

                img {
                    src = resourceUri
                }

                span {
                    css {
                        marginLeft = 1.em
                    }
                    renderDelete(resource.key)
                }

                hr {}
            }
        }


        div {
            css {
                padding = Padding(1.em, 1.em, 0.px, 1.em)
            }

            val capturedDataUrl = state.capturedDataUrl
            val screenshotDataUrl = state.screenshotDataUrl

            when {
                capturedDataUrl != null -> {
                    renderCapture()

                    br {}

                    renderDataUrl(capturedDataUrl)
                }

                screenshotDataUrl != null -> {
                    div {
                        css {
                            marginBottom = 0.5.em
                        }
                        renderSave()
                        renderRefresh()
                    }
                    renderCropper(screenshotDataUrl)
                }

                else ->
                    +"<taking screenshot>"
            }
        }
    }


    private fun ChildrenBuilder.renderDataUrl(dataUrl: String) {
        img {
            src = dataUrl
        }
    }


    private fun ChildrenBuilder.renderCapture() {
        div {
            Button {
                sx {
                    backgroundColor = NamedColor.white
                }
                variant = ButtonVariant.outlined
                size = Size.small

                onClick = { onCapture() }

                icon("material-symbols:photo-camera") {
                    style = unsafeJso {
                        marginRight = 0.25.em
                    }
                }
                +"Capture"
            }
        }
    }


    private fun ChildrenBuilder.renderSave() {
        div {
            css {
                display = Display.inlineBlock
            }

            Button {
                sx {
                    backgroundColor = NamedColor.white
                }

                variant = ButtonVariant.outlined
                size = Size.small

                onClick = { onSave() }

                icon("material-symbols:photo-camera") {
                    style = unsafeJso {
                        marginRight = 0.25.em
                    }
                }
                +"Save"
            }
        }
    }


    private fun ChildrenBuilder.renderRefresh() {
        div {
            css {
                display = Display.inlineBlock
            }

            Button {
                sx {
                    backgroundColor = NamedColor.white
                }
                variant = ButtonVariant.outlined
                size = Size.small

                onClick = { onRefresh() }

                icon("material-symbols:refresh") {
                    style = unsafeJso {
                        marginRight = 0.25.em
                    }
                }
                +"Refresh Screenshot"
            }
        }
    }


    private fun ChildrenBuilder.renderDelete(
            resourcePath: ResourcePath
    ) {
        div {
            css {
                display = Display.inlineBlock
            }

            Button {
                sx {
                    backgroundColor = NamedColor.white
                }
                variant = ButtonVariant.outlined
                size = Size.small

                onClick = {
                    onRemove(resourcePath)
                }

                title = "Delete"

                icon("material-symbols:delete") {
                    style = unsafeJso {
                        marginRight = 0.25.em
                    }
                }
            }
        }
    }


    private fun ChildrenBuilder.renderCropper(
            screenshotDataUrl: String
    ) {
        div {
            css {
                width = 100.pct
                height = 100.vh.minus(10.em)
                minHeight = 200.px
                maxHeight = 1024.px
            }

            CropperWrapper::class.react {
                src = screenshotDataUrl

                crop = { event ->
                    @Suppress("UNCHECKED_CAST_TO_EXTERNAL_INTERFACE")
                    @OptIn(ExperimentalWasmJsInterop::class)
                    val detail = event.detail as CropperDetail
                    onCrop(detail)
                }

                ref = cropperWrapper
            }
        }
    }
}