//package tech.kzen.project.client.objects
//
//interface Executable<I, out T> {
//    fun execute(input: I): T
//}