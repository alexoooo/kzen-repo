//package tech.kzen.project.client.objects
//
//import react.RBuilder
//import react.ReactElement
//
//interface ReactWrapper: Executable<RBuilder, ReactElement>