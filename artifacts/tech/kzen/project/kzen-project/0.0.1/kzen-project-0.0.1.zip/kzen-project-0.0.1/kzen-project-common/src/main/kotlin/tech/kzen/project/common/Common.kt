package tech.kzen.project.common

expect fun getAnswerBar(): Int
