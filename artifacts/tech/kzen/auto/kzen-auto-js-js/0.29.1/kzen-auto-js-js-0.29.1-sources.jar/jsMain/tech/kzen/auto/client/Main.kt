package tech.kzen.auto.client

import react.Fragment
import react.StrictMode
import react.create
import react.dom.client.createRoot
import tech.kzen.auto.client.api.ReactWrapper
import tech.kzen.auto.client.service.ClientContext
import tech.kzen.auto.client.util.async
import tech.kzen.auto.common.api.rootHtmlElementId
import tech.kzen.auto.common.util.AutoConventions
import tech.kzen.lib.common.model.instance.GraphInstance
import tech.kzen.lib.common.model.location.ObjectReference
import web.dom.ElementId
import web.dom.document
import web.events.EventHandler
import web.html.HTMLElement
import web.window.window


fun main() {
    fun emptyRootElement(): HTMLElement {
        val rootElement = document.getElementById(ElementId(rootHtmlElementId))
            ?: throw IllegalStateException("'$rootHtmlElementId' element not found")

        while (rootElement.hasChildNodes()) {
            rootElement.removeChild(rootElement.firstChild!!)
        }
        return rootElement
    }

    window.onload = EventHandler {
        async {
            val clientContext: ClientContext =
                try {
                    ClientContext.create()
                }
                catch (t: Throwable) {
                    val rootElement = emptyRootElement()
                    rootElement.textContent = "Error: ${t.message}"
                    throw t
                }

            val clientGraphDefinition = clientContext.mirroredGraphStore
                    .graphDefinition()
                    .successful()
                    .filterDefinitions(AutoConventions.clientUiAllowed)
//            console.log("^^^ filteredGraphDefinition - $clientGraphDefinition")

            val clientGraphInstance: GraphInstance =
                try {
                    clientContext.graphCreator.createGraph(
                        clientGraphDefinition, clientContext.graphEnvironment)
                }
                catch (t: Throwable) {
                    val rootElement = emptyRootElement()
                    rootElement.textContent = "Error: ${t.message}"
                    throw t
                }

//            console.log("^^^ main autoGraph ^^ ", autoGraph.objects.values.keys.toString())
            val rootLocation = clientGraphInstance
                    .objectInstances
                    .locate(ObjectReference.parse("root"))

            val rootInstance = clientGraphInstance
                    .objectInstances[rootLocation]
                    ?.reference
                    as? ReactWrapper<*>
                    ?: throw IllegalStateException("Missing root object")

            val rootElement = emptyRootElement()
            val root = createRoot(rootElement)
            root.render(Fragment.create {
                StrictMode {
                    rootInstance.child(this) {}
                }
            })
        }
    }
}
