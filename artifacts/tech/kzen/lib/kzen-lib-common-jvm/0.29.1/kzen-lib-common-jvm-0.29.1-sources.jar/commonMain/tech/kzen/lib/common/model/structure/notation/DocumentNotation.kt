package tech.kzen.lib.common.model.structure.notation

import tech.kzen.lib.common.model.attribute.AttributeName
import tech.kzen.lib.common.model.document.DocumentPath
import tech.kzen.lib.common.model.location.ObjectLocation
import tech.kzen.lib.common.model.location.ObjectLocationMap
import tech.kzen.lib.common.model.obj.ObjectPath
import tech.kzen.lib.common.model.structure.resource.ResourceListing
import tech.kzen.lib.common.model.structure.resource.ResourcePath
import tech.kzen.lib.common.util.digest.Digest
import tech.kzen.lib.common.util.digest.Digestible
import tech.kzen.lib.platform.ClassName
import tech.kzen.lib.platform.collect.toPersistentMap


data class DocumentNotation(
    val objects: DocumentObjectNotation,
    val resources: ResourceListing?
):
    Digestible
{
    //-----------------------------------------------------------------------------------------------------------------
    companion object {
        val empty = DocumentNotation(DocumentObjectNotation.empty, null)

        // Sentinel for a pure folder (a markerless directory, not a document). Has no objects and no resources;
        // distinguished from `empty` by DocumentObjectNotation.folder. Never written to a file — the media just
        // creates the directory (see DirectGraphStore / FileNotationMedia.createFolder).
        val folder = DocumentNotation(DocumentObjectNotation.folder, null)

        val className = ClassName(
            "tech.kzen.lib.common.model.structure.notation.DocumentNotation")


        fun ofObjectsWithEmptyOrNullResources(
            objects: DocumentObjectNotation,
            directory: Boolean
        ): DocumentNotation {
            return DocumentNotation(
                    objects,
                    ResourceListing.emptyOrNull(directory))
        }
    }


    //-----------------------------------------------------------------------------------------------------------------
    private var digest: Digest? = null


    //-----------------------------------------------------------------------------------------------------------------
    fun isFolder(): Boolean {
        return objects.isFolder()
    }


    fun assertDocument(documentPath: DocumentPath? = null) {
        check(!isFolder()) { "Folder used where a document is required: $documentPath" }
    }


    fun assertFolder(documentPath: DocumentPath? = null) {
        check(isFolder()) { "Document used where a folder is required: $documentPath" }
    }


    //-----------------------------------------------------------------------------------------------------------------
    // NB: a folder has no objects, so this naturally yields an empty map — folders contribute nothing to the
    // graph definition / coalesce / metadata pipeline.
    fun expand(path: DocumentPath): ObjectLocationMap<ObjectNotation> {
        val values = mutableMapOf<ObjectLocation, ObjectNotation>()

        for (e in objects.notations.map) {
            values[ObjectLocation(path, e.key)] = e.value
        }

        return ObjectLocationMap(values.toPersistentMap())
    }


    //-----------------------------------------------------------------------------------------------------------------
//    val digest: Digest by lazy {
//        val combiner = Digest.UnorderedCombiner()
//        for (e in objects) {
//            combiner.add(Digest.ofXoShiRo256StarStar(e.key))
//            combiner.add(Digest.ofXoShiRo256StarStar(e.value))
//        }
//        return@lazy combiner.combine()
//    }

//    fun nameAt(index: Int): ObjectName {
//        return objects.values.keys.toList()[index].name
//    }


    fun indexOf(objectPath: ObjectPath): PositionIndex {
        return PositionIndex(objects.notations.map.keys.indexOf(objectPath))
    }


    // The objects nested directly under parentObjectPath at the given attribute, in document order.
    // Membership and order are derived purely from object paths and insertion order — the same rule
    // NestedListAttributeDefiner uses to auto-wire a parent's child-list attribute (e.g. Script steps).
    // (startsWith already guarantees the segment at parentDepth names parentObjectPath.)
    fun directNestedObjectPaths(
        parentObjectPath: ObjectPath,
        attributeName: AttributeName
    ): List<ObjectPath> {
        val parentDepth = parentObjectPath.nesting.segments.size
        return objects.notations.map.keys.filter { childPath ->
            childPath.startsWith(parentObjectPath) &&
            childPath.nesting.segments.size == parentDepth + 1 &&
            childPath.nesting.segments[parentDepth].attributePath.attribute == attributeName
        }
    }


//    fun equalsInOrder(other: DocumentNotation): Boolean {
//        return this == other &&
//                objects.keys.toList() == other.objects.keys.toList()
//    }


    //-----------------------------------------------------------------------------------------------------------------
    fun withModifiedObject(
        objectPath: ObjectPath,
        objectNotation: ObjectNotation
    ): DocumentNotation {
        return copy(objects = objects
            .withModifiedObject(objectPath, objectNotation))
    }


    fun withNewObject(
        positionedObjectPath: PositionedObjectPath,
        objectNotation: ObjectNotation
    ): DocumentNotation {
        return copy(objects = objects
            .withNewObject(positionedObjectPath, objectNotation))
    }


    fun withoutObject(
        objectPath: ObjectPath
    ): DocumentNotation {
        return copy(objects = objects
            .withoutObject(objectPath))
    }


    fun withObjects(
        objects: DocumentObjectNotation
    ): DocumentNotation {
        assertDocument()
        check(!objects.isFolder()) { "Cannot set a document's objects to a folder marker" }
        return copy(objects = objects)
    }


    fun withNewResource(
        resourcePath: ResourcePath,
        contentDigest: Digest
    ): DocumentNotation {
        assertDocument()

        val resources = resources
            ?: throw IllegalStateException("Resources not allowed")

        return copy(resources = resources
            .withNewResource(resourcePath, contentDigest))
    }


    fun withoutResource(
        resourcePath: ResourcePath
    ): DocumentNotation {
        assertDocument()

        val resources = resources
            ?: throw IllegalStateException("Resources not allowed")

        return copy(resources = resources
                .withoutResource(resourcePath))
    }


    //-----------------------------------------------------------------------------------------------------------------
    override fun digest(sink: Digest.Sink) {
        sink.addDigest(digest())
    }


    override fun digest(): Digest {
        if (digest == null) {
            val builder = Digest.Builder()

            builder.addDigestible(objects)
            builder.addDigestibleNullable(resources)

            digest = builder.digest()
        }
        return digest!!
    }


    override fun toString(): String {
        return "[$objects | $resources]"
    }
}
