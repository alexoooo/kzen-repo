package tech.kzen.auto.client.objects.document.report.formula

import emotion.react.css
import js.objects.unsafeJso
import mui.material.IconButton
import react.ChildrenBuilder
import react.dom.html.ReactHTML.div
import tech.kzen.auto.client.wrap.RPureComponent
import tech.kzen.auto.client.wrap.iconify.icon
import tech.kzen.auto.client.wrap.select.SelectOption
import tech.kzen.auto.client.wrap.select.muiAutocompleteField
import tech.kzen.auto.client.wrap.setState
import tech.kzen.auto.common.objects.document.report.listing.HeaderLabel
import tech.kzen.auto.common.objects.document.report.listing.HeaderListing
import web.cssom.Display
import web.cssom.WhiteSpace
import web.cssom.em


//---------------------------------------------------------------------------------------------------------------------
external interface FormulaReferenceControllerProps: react.Props {
    var inputColumns: HeaderListing
    var editDisabled: Boolean
    var onAdded: (HeaderLabel) -> Unit
    var addLabel: String
    var addIcon: String
}


external interface FormulaReferenceControllerState: react.State {
    var adding: Boolean
    var selectedColumn: HeaderLabel?
}


//---------------------------------------------------------------------------------------------------------------------
class FormulaReferenceController(
    props: FormulaReferenceControllerProps
):
    RPureComponent<FormulaReferenceControllerProps, FormulaReferenceControllerState>(props)
{
    //-----------------------------------------------------------------------------------------------------------------
    override fun FormulaReferenceControllerState.init(props: FormulaReferenceControllerProps) {
        adding = false
        selectedColumn = null
    }


    //-----------------------------------------------------------------------------------------------------------------
    private fun onAdd() {
        setState {
            adding = true
            selectedColumn = null
        }
    }


    private fun onCancel() {
        setState {
            adding = false
//            selectedColumn = null
        }
    }


    private fun onValueChange(columnName: HeaderLabel) {
        props.onAdded.invoke(columnName)

        setState {
            selectedColumn = columnName
            adding = false
            selectedColumn = null
        }
    }


    //-----------------------------------------------------------------------------------------------------------------
    override fun ChildrenBuilder.render() {
        div {
            css {
                if (state.adding) {
                    marginBottom = (-1).em
                    marginLeft = 0.5.em
                }

                whiteSpace = WhiteSpace.nowrap
            }

            if (state.adding) {
                div {
                    css {
                        display = Display.inlineBlock
                        width = 15.em
                    }

                    renderSelect()
                }

                renderCancel()
            }
            else {
                renderAddButton()
            }
        }
    }


    private fun ChildrenBuilder.renderAddButton() {
        div {
            title = props.addLabel

            css {
                display = Display.inlineBlock
            }

            IconButton {
                onClick = {
                    onAdd()
                }

                icon(props.addIcon) {}
            }
        }
    }


    private fun ChildrenBuilder.renderCancel() {
        div {
            css {
                display = Display.inlineBlock
            }

            IconButton {
                title = "Cancel"
                onClick = {
                    onCancel()
                }
                icon("material-symbols:cancel") {}
            }
        }
    }


    private fun ChildrenBuilder.renderSelect() {
        val selectOptions = props
            .inputColumns
            .values
            .map {
                val option: SelectOption = unsafeJso {
                    value = it.asString()
                    label = it.render()
                }
                option
            }
            .toTypedArray()

        muiAutocompleteField(
            label = "Column",
            options = selectOptions,
            selectedOption = selectOptions.find { HeaderLabel.ofString(it.value) == state.selectedColumn },
            onSelect = { onValueChange(HeaderLabel.ofString(it.value)) },
            disabled = props.editDisabled,
            disableClearable = true,
            autoFocus = true,
            openOnFocus = true)
    }
}