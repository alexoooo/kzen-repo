package tech.kzen.project.common

actual fun getAnswerBar() = 42
