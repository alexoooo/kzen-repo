package tech.kzen.lib.common.service.store

import tech.kzen.lib.common.model.definition.GraphDefinitionAttempt
import tech.kzen.lib.common.model.document.DocumentPath
import tech.kzen.lib.common.model.document.DocumentPathMap
import tech.kzen.lib.common.model.location.ResourceLocation
import tech.kzen.lib.common.model.structure.GraphStructure
import tech.kzen.lib.common.model.structure.notation.DocumentNotation
import tech.kzen.lib.common.model.structure.notation.DocumentObjectNotation
import tech.kzen.lib.common.model.structure.notation.GraphNotation
import tech.kzen.lib.common.model.structure.notation.cqrs.*
import tech.kzen.lib.common.model.structure.scan.NotationScan
import tech.kzen.lib.common.service.context.GraphDefiner
import tech.kzen.lib.common.service.media.NotationMedia
import tech.kzen.lib.common.service.metadata.NotationMetadataReader
import tech.kzen.lib.common.service.notation.NotationReducer
import tech.kzen.lib.common.service.parse.NotationParser
import tech.kzen.lib.common.util.digest.Digest
import tech.kzen.lib.common.util.digest.DigestCache
import tech.kzen.lib.platform.collect.toPersistentMap


class DirectGraphStore(
    private val notationMedia: NotationMedia,
    private val notationParser: NotationParser,
    private val notationMetadataReader: NotationMetadataReader,
    private val graphDefiner: GraphDefiner,
    private val notationReducer: NotationReducer
):
    LocalGraphStore
{
    //-----------------------------------------------------------------------------------------------------------------
    private var graphNotationCacheDigest: Digest? = null
    private var graphNotationCache: GraphNotation? = null
    private val documentObjectCache = DigestCache<DocumentObjectNotation>(128)

    private val observers = mutableSetOf<LocalGraphStore.Observer>()


    //-----------------------------------------------------------------------------------------------------------------
    override suspend fun observe(observer: LocalGraphStore.Observer) {
        observers.add(observer)

        val graphDefinition = graphDefinition()
        observer.onStoreRefresh(graphDefinition)
    }


    override fun unobserve(observer: LocalGraphStore.Observer) {
        observers.remove(observer)
    }


    private suspend fun publishSuccess(
        event: NotationEvent,
        attachment: LocalGraphStore.Attachment
    ) {
        val graphDefinition = graphDefinition()

        for (observer in observers) {
            observer.onCommandSuccess(event, graphDefinition, attachment)
        }
    }


    private suspend fun publishFailure(
        command: NotationCommand,
        cause: Throwable,
        attachment: LocalGraphStore.Attachment
    ) {
        for (observer in observers) {
            observer.onCommandFailure(command, cause, attachment)
        }
    }


    private suspend fun publishRefresh() {
        val graphDefinition = graphDefinition()

        for (observer in observers) {
            observer.onStoreRefresh(graphDefinition)
        }
    }


    //-----------------------------------------------------------------------------------------------------------------
    override suspend fun graphNotation(): GraphNotation {
        val notationScan = notationMedia.scan()
        return graphNotation(notationScan)
    }


    private suspend fun graphNotation(notationScan: NotationScan): GraphNotation {
        val digest = notationScan.digest()

        if (graphNotationCacheDigest != digest) {
            graphNotationCacheDigest = digest
            graphNotationCache = graphNotationImpl(notationScan)
        }

        return graphNotationCache!!
    }


    private suspend fun graphNotationImpl(notationScan: NotationScan): GraphNotation {
        val documentBodies = mutableMapOf<DocumentPath, String>()
        val documents = mutableMapOf<DocumentPath, DocumentNotation>()

        for (e in notationScan.documents.map) {
            val projectPath = e.key

            if (projectPath.folder) {
                // a folder is a markerless directory with no body to read
                documents[projectPath] = DocumentNotation.folder
                continue
            }

            val body = notationMedia.readDocument(projectPath, e.value.documentDigest)

            documentBodies[projectPath] = body

            val cachedDocumentObjectNotation = documentObjectCache.get(e.value.documentDigest)
            if (cachedDocumentObjectNotation != null) {
                documents[projectPath] = DocumentNotation(cachedDocumentObjectNotation, e.value.resources)
            }
            else {
                val documentObjectNotation = notationParser.parseDocumentObjects(body)
                documents[projectPath] = DocumentNotation(documentObjectNotation, e.value.resources)

                documentObjectCache.put(e.value.documentDigest, documentObjectNotation)
            }
        }

        return GraphNotation(DocumentPathMap(documents.toPersistentMap()))
    }


    override suspend fun graphStructure(): GraphStructure {
        val graphNotation = graphNotation()
        return graphStructure(graphNotation)
    }


    private fun graphStructure(
        graphNotation: GraphNotation
    ): GraphStructure {
        val graphMetadata = notationMetadataReader.read(graphNotation)
        return GraphStructure(graphNotation, graphMetadata)
    }


    override suspend fun graphDefinition(): GraphDefinitionAttempt {
        val graphStructure = graphStructure()
        return graphDefinition(graphStructure)
    }


    private fun graphDefinition(
        graphNotation: GraphNotation
    ): GraphDefinitionAttempt {
        val graphStructure = graphStructure(graphNotation)
        return graphDefinition(graphStructure)
    }


    private fun graphDefinition(
        graphStructure: GraphStructure
    ): GraphDefinitionAttempt {
        return graphDefiner.tryDefine(graphStructure)
    }


    suspend fun digest(): Digest {
        return notationMedia.scan().digest()
    }


    //-----------------------------------------------------------------------------------------------------------------
    suspend fun apply(
        command: NotationCommand,
        attachment: LocalGraphStore.Attachment = LocalGraphStore.Attachment.empty
    ): NotationEvent {
        val notationEvent = applyInPlace(command)
        publishSuccess(notationEvent, attachment)
        return notationEvent
    }


    private suspend fun applyInPlace(
        command: NotationCommand
    ): NotationEvent {
        val notationScan = notationMedia.scan()
        val graphNotation = graphNotation(notationScan)

        val transition =
            when (command) {
                is StructuralNotationCommand ->
                    notationReducer.applyStructural(graphNotation, command)

                is SemanticNotationCommand -> {
                    val graphDefinitionAttempt = graphDefinition(graphNotation)
                    notationReducer.applySemantic(graphDefinitionAttempt, command)
                }
            }

        val newGraphNotation = transition.graphNotation

        writeModified(graphNotation, newGraphNotation, command, transition, notationScan)

        val removedDocumentPaths = graphNotation.documents.map.keys
            .minus(newGraphNotation.documents.map.keys)
            // deepest-first: a folder's contents are removed before the (now-empty) folder directory itself.
            // Every folder has its own scan/notation entry, so a DeleteFolderCommand's cascade puts the folder
            // directory here too — the generic loop removes it; no special-casing needed.
            .sortedByDescending { it.nesting.segments.size }

        for (removed in removedDocumentPaths) {
            delete(removed)
        }

        return transition.notationEvent
    }


    private suspend fun writeModified(
            oldGraphNotation: GraphNotation,
            newGraphNotation: GraphNotation,
            command: NotationCommand,
            transition: NotationTransition,
            oldNotationScan: NotationScan
    ) {
        val copiedDocumentEvents =
            (transition.notationEvent as? CompoundNotationEvent)
                ?.singularEvents
                ?.filterIsInstance<CopiedDocumentEvent>()
                ?: listOf()

        for (updatedDocument in newGraphNotation.documents.map) {
            val oldDocument = oldGraphNotation.documents.map[updatedDocument.key]

            val copiedDocumentEvent =
                if (oldDocument != null) {
                    null
                }
                else {
                    copiedDocumentEvents.find { it.destination == updatedDocument.key }
                }

            if (copiedDocumentEvent != null) {
                val oldDocumentScan = oldNotationScan.documents[copiedDocumentEvent.documentPath]

                writeCopy(
                    oldGraphNotation,
                    newGraphNotation,
                    copiedDocumentEvent,
                    oldDocumentScan?.documentDigest)
            }
            else {
                val oldDocumentScan = oldNotationScan.documents[updatedDocument.key]

                writeIfRequired(
                    updatedDocument.key,
                    updatedDocument.value,
                    command,
                    oldDocument,
                    oldDocumentScan?.documentDigest)
            }
        }
    }


    private suspend fun writeCopy(
        oldGraphNotation: GraphNotation,
        newGraphNotation: GraphNotation,
        copiedDocumentEvent: CopiedDocumentEvent,
        originalDocumentDigest: Digest?
    ) {
        val sourceDocumentPath = copiedDocumentEvent.documentPath
        val destinationDocumentPath = copiedDocumentEvent.destination

        val sourceDocumentContents = notationMedia
                .readDocument(sourceDocumentPath, originalDocumentDigest)

        val sourceDocument = oldGraphNotation.documents[sourceDocumentPath]!!
        val destinationDocument = newGraphNotation.documents[destinationDocumentPath]!!

        // A folder relocation that rewrote intra-subtree references changes the copied body; persist the
        // rewritten notation in that case (using the source body as the unparse template for a minimal diff).
        // A pure copy/move keeps the byte-for-byte source so formatting/comments that parse→unparse would
        // lose are preserved.
        val destinationContents =
            if (destinationDocument.objects == sourceDocument.objects) {
                sourceDocumentContents
            }
            else {
                notationParser.unparseDocument(destinationDocument.objects, sourceDocumentContents)
            }

        notationMedia.writeDocument(destinationDocumentPath, destinationContents)

        if (sourceDocument.resources != null) {
            for (resourcePath in sourceDocument.resources.digests.keys) {
                notationMedia.copyResource(
                    ResourceLocation(sourceDocumentPath, resourcePath),
                    ResourceLocation(destinationDocumentPath, resourcePath))
            }
        }
    }


    private suspend fun writeIfRequired(
        documentPath: DocumentPath,
        documentNotation: DocumentNotation,
        command: NotationCommand,
        originalDocument: DocumentNotation?,
        originalDocumentDigest: Digest?
    ) {
        if (documentNotation == originalDocument) {
            return
        }

        if (documentPath.folder) {
            // a folder is persisted as a bare directory — no body to unparse/write; just ensure the dir exists.
            // the path form is authoritative; assert the notation agrees so the two can never diverge.
            documentNotation.assertFolder(documentPath)
            if (originalDocument == null) {
                notationMedia.createFolder(documentPath)
            }
            return
        }
        documentNotation.assertDocument(documentPath)

        val previouslyPresent = originalDocument != null

        val previousBody: String =
            if (previouslyPresent) {
                notationMedia.readDocument(documentPath, originalDocumentDigest)
            }
            else {
                ""
            }

        val updatedBody = notationParser.unparseDocument(documentNotation.objects, previousBody)

        if (updatedBody != previousBody || !previouslyPresent) {
            notationMedia.writeDocument(documentPath, updatedBody)
        }

        when (command) {
            is ResourceNotationCommand -> {
                when (command) {
                    is AddResourceCommand -> {
                        notationMedia.writeResource(
                            command.resourceLocation,
                            command.resourceContent)
                    }

                    is RemoveResourceCommand -> {
                        notationMedia.deleteResource(command.resourceLocation)
                    }
                }
            }

            else -> {}
        }
    }


    private suspend fun delete(
        documentPath: DocumentPath
    ) {
        notationMedia.deleteDocument(documentPath)
    }


    //-----------------------------------------------------------------------------------------------------------------
    fun refresh() {
        notationMedia.invalidate()
        graphNotationCacheDigest = null
        graphNotationCache = null
    }
}