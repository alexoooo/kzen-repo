package tech.kzen.auto.common.paradigm.flow.api

import tech.kzen.lib.common.exec.ExecutionValue


/**
 * Must inject RequiredInput for use in the process method,
 *  can also inject more than one RequiredInput or additional OptionalInput.
 *
 * Can inject (at most one of) RequiredOutput or OptionalOutput.
 *
 * See: https://en.wikipedia.org/wiki/Pipe_(fluid_conveyance)
 * See: https://en.wikipedia.org/wiki/Piping_and_plumbing_fitting
 *
 * TODO: rename to Vertex?
 * TODO: use ExecutionState<T> fields for internalized state, inline with
 */
interface FlowVertex<State> {
    /**
     * Externalized state, null for StatelessFlowVertex
     */
    fun initialState(): State


    /**
     * Non-functional view, like a structured toString
     */
    fun inspectState(state: State): ExecutionValue


    /**
     * Make use of injected RequiredInput (and OptionalInput), plus any direct object references.
     *
     * Can also use injected RequiredOutput (or OptionalOutput).
     */
    fun process(state: State): State
}