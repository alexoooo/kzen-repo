package tech.kzen.auto.client.objects.document.report.run

import js.objects.unsafeJso
import mui.material.Fab
import mui.system.sx
import react.ChildrenBuilder
import react.Props
import react.State
import tech.kzen.auto.client.objects.document.report.model.ReportStore
import tech.kzen.auto.client.wrap.RPureComponent
import tech.kzen.auto.client.wrap.iconify.icon
import web.cssom.NamedColor
import web.cssom.em


//---------------------------------------------------------------------------------------------------------------------
external interface ReportRunControllerProps: Props {
    var thisRunning: Boolean
    var outputTerminal: Boolean
    var reportStore: ReportStore
}


//---------------------------------------------------------------------------------------------------------------------
class ReportRunController(
    props: ReportRunControllerProps
):
    RPureComponent<ReportRunControllerProps, State>(props)
{
    //-----------------------------------------------------------------------------------------------------------------
    private fun onRunMain() {
        props.reportStore.output.resetAsync()
    }


    //-----------------------------------------------------------------------------------------------------------------
    override fun ChildrenBuilder.render() {
        renderMainAction()
    }


    //-----------------------------------------------------------------------------------------------------------------
    private fun ChildrenBuilder.renderMainAction() {
        if (props.thisRunning || !props.outputTerminal) {
            return
        }

        Fab {
            sx {
                backgroundColor = NamedColor.white
                width = 5.em
                height = 5.em
            }

            onClick = {
                onRunMain()
            }

            title = "Reset"

            icon("material-symbols:replay") {
                style = unsafeJso {
                    fontSize = 3.em
                }
            }
        }
    }
}